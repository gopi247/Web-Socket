﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ConsoleApp_Delete.ServiceReference1;


namespace ConsoleApp_Delete
{
    [CallbackBehavior(UseSynchronizationContext = false)]
    public class Wrapper : ITestServiceCallback
    {
        private ITestService mClient;
        private SynchronizationContext mSyncContext;
        public event EventHandler<string> callBackString;
        public Wrapper()
        {
            try
            {
                var Inst = new InstanceContext(this);
                var b = new NetHttpBinding(BasicHttpSecurityMode.None);
                b.SendTimeout = new TimeSpan(1, 59, 59);
                b.ReceiveTimeout = new TimeSpan(1, 59, 59);
                b.MaxBufferPoolSize = int.MaxValue;
                b.MaxReceivedMessageSize = int.MaxValue;
                b.MaxBufferSize = int.MaxValue;

                var cf = new DuplexChannelFactory<ITestService>(Inst, b);
                var HosAddr = new EndpointAddress("ws://localhost:13060/");
                mClient = cf.CreateChannel(HosAddr);
                mSyncContext = SynchronizationContext.Current;

                if (mClient != null)
                {
                    Console.WriteLine("initilized");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                Console.ReadKey();
            }
        }


        public string Response()
        {
            return mClient.GetData("Hello");
        }

        public void MyCallBack(string result)
        {
            callBackString.Invoke(this, result);
        }
    }
}
