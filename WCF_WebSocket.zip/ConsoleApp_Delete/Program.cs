using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_Delete
{
    class Program
    {
        static void Main(string[] args)
        {
            
            try
            {
                var client = new  ServiceReference1.TestServiceClient();
                Console.WriteLine(client.GetData("sdf").ToString());
                //Wrapper wrapper = new Wrapper();
                //wrapper.callBackString += Wrapper_callBackString;
                //string response = wrapper.Response();
                //Console.WriteLine(response);
                Console.ReadKey();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                Console.ReadKey();
            }
           
        }

        private static void Wrapper_callBackString(object sender, string e)
        {
            Console.WriteLine(e);
            Console.WriteLine("\n");
        }
    }
}
