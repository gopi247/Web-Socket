﻿using ServiceReference1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading;
using System.Threading.Tasks;


namespace ConsumeService
{
    
    public class Wrapper 
    {
        ITestService mClient;
        private SynchronizationContext mSyncContext;
        public event EventHandler<string> callBackString;
        public Wrapper()
        {
            try
            {

                var Inst = new InstanceContext(this);
                CustomBinding customBinding = new CustomBinding();
                customBinding.Elements.Add(new TextMessageEncodingBindingElement());
                customBinding.Elements.Add(new HttpTransportBindingElement());

                customBinding.SendTimeout = new TimeSpan(1, 59, 59);
                customBinding.ReceiveTimeout = new TimeSpan(1, 59, 59);
                var add = new EndpointAddress("http://localhost:13060/");
                var cf = new ChannelFactory<ITestService>(customBinding, add);
                mClient = cf.CreateChannel(add);
                string str = mClient.GetDataAsync("Hello").Result;
                if (mClient != null)
                {
                    Console.WriteLine("initilized");
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                Console.ReadKey();
            }
        }


        public void NetHttpBinding()

        {
            try
            {
                var b = new NetHttpBinding(BasicHttpSecurityMode.None);
                b.SendTimeout = new TimeSpan(1, 59, 59);
                b.ReceiveTimeout = new TimeSpan(1, 59, 59);
                b.MaxBufferPoolSize = int.MaxValue;
                b.MaxReceivedMessageSize = int.MaxValue;
                b.MaxBufferSize = int.MaxValue;
                var address = new EndpointAddress("http://localhost:13060/");
                var cf = new ChannelFactory<ITestService>(b, address);
                mClient = cf.CreateChannel(address);

                if (mClient != null)
                {
                    Console.WriteLine("initilized");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                Console.ReadKey();
            }
        }


        public void Response()
        {
            try
            {
                string str = mClient.GetDataAsync("Hello").Result;
                Console.WriteLine(str);
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex);
                Console.ReadKey();
            }
           
        }

        public void MyCallBack(string result)
        {
            CustomBinding customBinding = new CustomBinding();
            customBinding.Elements.Add(new TextMessageEncodingBindingElement());
            customBinding.Elements.Add(new HttpTransportBindingElement());
            customBinding.SendTimeout = new TimeSpan(1, 59, 59);
            customBinding.ReceiveTimeout = new TimeSpan(1, 59, 59);
            var add = new EndpointAddress("ws://localhost:8888/");
            var cf = new ChannelFactory<ITestService>(customBinding, add);
            mClient = cf.CreateChannel(add);

            if (mClient != null)
            {
                Console.WriteLine("initilized");
            }
        }
    }
}
