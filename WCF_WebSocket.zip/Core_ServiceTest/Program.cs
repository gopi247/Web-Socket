﻿using ServiceReference1;
using System;

namespace Core_ServiceTest
{
    class Program
    {
        static void Main(string[] args)
        {
            Wrapper wrapper = new Wrapper();
            wrapper.callBackString += Wrapper_callBackString;
            string response = wrapper.Response().Result;
            Console.WriteLine(response);
            Console.ReadKey();
        }

        private static void Wrapper_callBackString(object sender, string e)
        {
            Console.WriteLine(e);
        }
    }
}
