﻿using ServiceReference1;
using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Core_ServiceTest
{
   public class Wrapper : ITestServiceCallback
        {
            private ITestService mClient;
            private SynchronizationContext mSyncContext;
            public event EventHandler<string> callBackString;
            public Wrapper()
            {
                try
                {
                    var Inst = new InstanceContext(this);
                    var b = new NetHttpBinding(BasicHttpSecurityMode.None);
                    b.SendTimeout = new TimeSpan(1, 59, 59);
                    b.ReceiveTimeout = new TimeSpan(1, 59, 59);
                    b.MaxBufferPoolSize = int.MaxValue;
                    b.MaxReceivedMessageSize = int.MaxValue;
                    b.MaxBufferSize = int.MaxValue;

                    var cf = new DuplexChannelFactory<ITestService>(Inst, b);
                    var HosAddr = new EndpointAddress("http://localhost:13060");
                    mClient = cf.CreateChannel(HosAddr);
                    mSyncContext = SynchronizationContext.Current;

                    if (mClient != null)
                    {
                        Console.WriteLine("initilized");
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                    Console.ReadKey();
                }
            }


            public Task<string> Response()
            {
                return mClient.GetDataAsync("Hello");
            }

            public void MyCallBack(string result)
            {
                callBackString.Invoke(this, result);
            }
           
        }
  
}
